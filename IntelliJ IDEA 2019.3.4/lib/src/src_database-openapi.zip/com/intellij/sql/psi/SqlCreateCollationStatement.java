package com.intellij.sql.psi;

/**
 * @author Gregory.Shrago
 */
public interface SqlCreateCollationStatement extends SqlCreateStatement {
}
