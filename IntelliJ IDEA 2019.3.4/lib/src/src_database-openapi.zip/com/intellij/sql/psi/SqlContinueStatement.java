package com.intellij.sql.psi;

public interface SqlContinueStatement extends SqlConditionalJumpStatement {
}