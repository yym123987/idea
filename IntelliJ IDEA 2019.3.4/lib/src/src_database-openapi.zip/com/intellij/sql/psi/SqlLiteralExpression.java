package com.intellij.sql.psi;

/**
 * @author Gregory.Shrago
 */
public interface SqlLiteralExpression extends SqlExpression {
}
