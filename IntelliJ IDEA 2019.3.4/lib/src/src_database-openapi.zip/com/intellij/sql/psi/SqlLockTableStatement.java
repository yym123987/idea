package com.intellij.sql.psi;

public interface SqlLockTableStatement extends SqlStatement {
}
