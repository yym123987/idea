package com.intellij.sql.psi;

public interface SqlBreakStatement extends SqlConditionalJumpStatement {
}