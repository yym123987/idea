package com.intellij.sql.psi;

/**
 * @author Gregory.Shrago
 */
public interface SqlCreateStatement extends SqlDdlStatement, SqlDefinition {
}
